package AEstrelaLabirinto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.PriorityQueue;

public class AEstrela {

	public static final int CUSTO_VERTICAL = 1; //custo movimento vertical
	public static final int CUSTO_HORIZONTAL = 1; //custo movimento horizontal
	
	private Campo[][] labirinto;
	private PriorityQueue<Campo> camposLivres;
	private boolean[][] camposOcupados;
	private int inicioI,inicioJ; //coordenadas de inicio
	private int fimI,fimJ; //coordenadas de fim
	String linha;
	FileReader leitorLabirinto;
	BufferedReader bufferLabirinto;
	
	public AEstrela(String nomeArquivo) {
		int horizontal,vertical,inI,inJ,fI,fJ;
		linha = new String();
		File arquivo = new File(nomeArquivo);
		
		if(arquivo.exists()) {
			try{
				leitorLabirinto = new FileReader(nomeArquivo);
				bufferLabirinto = new BufferedReader(leitorLabirinto);
				linha = bufferLabirinto.readLine();
				String[] tamLabirinto = linha.split(",");
				horizontal = Integer.parseInt(tamLabirinto[0]);
				vertical = Integer.parseInt(tamLabirinto[1]);
				
				labirinto = new Campo[horizontal][vertical];
				camposOcupados = new boolean[horizontal][vertical];
				camposLivres = new PriorityQueue<Campo>((Campo c1, Campo c2) -> {
					if(c1.custoF < c2.custoF) {
						return -1;
					} else if (c1.custoF > c2.custoF){
						return 1;
					} else {
						return 0;
					}
				});
				
				linha = bufferLabirinto.readLine();
				String[] coordenadaInicial = linha.split(",");
				inI = Integer.parseInt(coordenadaInicial[0]);
				inJ = Integer.parseInt(coordenadaInicial[1]);
				
				campoInicial(inI,inJ);
				
				linha = bufferLabirinto.readLine();
				String[] coordenadaFinal = linha.split(",");
				fimI = Integer.parseInt(coordenadaFinal[0]);
				fimJ = Integer.parseInt(coordenadaFinal[1]);
				
				campoFinal(fimI,fimJ);
								
				//criar campos e calcular valor heuristico
				for(int i = 0; i < labirinto.length; i++) {
					for(int j = 0; j < labirinto[i].length; j++) {
						labirinto[i][j] = new Campo(i,j);
						int difCampoFimVertical = Math.abs(i - fimI);
						int difCampoFimHorizontal = Math.abs(j - fimJ);
						labirinto[i][j].custoH = difCampoFimVertical + difCampoFimHorizontal;
						labirinto[i][j].caminho = false;
					}
				}
				
				labirinto[inicioI][inicioJ].custoF = 0;
				
				addParede();
				
			}catch(Exception e) {
				
			};
		};
	}

	public void addParede() {
		int a,b;
		try {
				while(true) {
					linha = bufferLabirinto.readLine();
					
					if(linha == null) {
						break;
					}
					String[] coordenadas = linha.split(",");
					a = Integer.parseInt(coordenadas[0]);
					b = Integer.parseInt(coordenadas[1]);
					labirinto[a][b] = null;
					
				}
			}catch(Exception e) {
				
			};
	};
	
	public void campoInicial(int i, int j) {
		inicioI = i;
		inicioJ = j;
	}
	
	public void campoFinal(int i, int j) {
		fimI = i;
		fimJ = j;
	}
	
	public void atualizarCusto(Campo atual, Campo c, int custo) {
		if(c == null || camposOcupados[c.i][c.j])
			return;
		
		int cCustoF = c.custoH + custo;
		boolean livre = camposLivres.contains(c);
		
		if(!livre || cCustoF < c.custoF) {
			c.custoF = cCustoF;
			c.parent = atual;
			
			if(!livre) {
				camposLivres.add(c);
			}
		}
	}
	
	public void processo() {
		camposLivres.add(labirinto[inicioI][inicioJ]);
		Campo atual;
		
		while(true) {
			atual = camposLivres.poll();
			
			if (atual == null) break;
			
			camposOcupados[atual.i][atual.j] = true;
			
			if (atual.equals(labirinto[fimI][fimJ])) return;
			
			Campo c;
			
			//mov cima, baixo, direita e esquerda
			if(atual.i - 1 >=0) { //pra cima
				c = labirinto[atual.i - 1][atual.j];
				atualizarCusto(atual,c,atual.custoF + CUSTO_VERTICAL);
			}
			
			if(atual.j - 1 >= 0) { //pra esquerda
				c = labirinto[atual.i][atual.j - 1];
				atualizarCusto(atual,c,atual.custoF + CUSTO_HORIZONTAL);
			}
			
			if(atual.j + 1 < labirinto[0].length) { //pra direita
				c = labirinto[atual.i][atual.j + 1];
				atualizarCusto(atual,c,atual.custoF + CUSTO_HORIZONTAL);
			}
			
			if(atual.i + 1 < labirinto.length) { //pra baixo
				c = labirinto[atual.i + 1][atual.j];
				atualizarCusto(atual,c,atual.custoF + CUSTO_VERTICAL);
			}
		}
	}
	
	public void exibirLabirinto() {
		System.out.println("Labirinto:");
		for(int i = 0; i < labirinto.length; i++) {
			for(int j = 0; j <labirinto[i].length; j++) {
				if(i == inicioI && j == inicioJ) {
					System.out.print("[I]");
				} else if (i == fimI && j == fimJ) {
					System.out.print("[F]");
				} else if (labirinto[i][j] != null) {
					System.out.print("[ ]");
				} else {
					System.out.print("[|]");
				}
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void exibirCustos() {
		System.out.println("Custos:");
		for(int i = 0; i < labirinto.length; i++) {
			for(int j = 0; j <labirinto[i].length; j++) {
				if(labirinto[i][j] != null) {
					System.out.print("[" + labirinto[i][j].custoF + "]");
				} else {
					System.out.print("[|]");
				}
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void exibirCaminho() {
		if(camposOcupados[fimI][fimJ]) {
			System.out.println("Caminho: ");
			Campo atual = labirinto[fimI][fimJ];
			System.out.println(atual);
			labirinto[atual.i][atual.j].caminho = true;
			
			while(atual.parent != null) {
				System.out.print(" -> " + atual.parent);
				labirinto[atual.parent.i][atual.parent.j].caminho = true;
				atual = atual.parent;
			}
			
			System.out.println("\n");
			
			for(int i = 0; i < labirinto.length; i++) {
				for(int j = 0; j <labirinto[i].length; j++) {
					if(i == inicioI && j == inicioJ) {
						System.out.print("[I]");
					} else if (i == fimI && j == fimJ) {
						System.out.print("[F]");
					} else if (labirinto[i][j] != null) {
						System.out.print(labirinto[i][j].caminho ? "[X]" : "[0]");
					} else {
						System.out.print("[|]");
					}
				}
				System.out.println();
			}
			System.out.println();
		} else {
			System.out.println("N�o h� nenhum caminho poss�vel!");
		}
	}
}