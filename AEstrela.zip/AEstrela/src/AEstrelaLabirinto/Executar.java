package AEstrelaLabirinto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Executar {

		
	public static void main(String[] args) {
		/*
		 * Montagem do .txt
		 * Linha 1 - Dimens�o do labirinto
		 * Linha 2 - Coordenada Ponto Inicial
		 * Linha 3 - Coordenada Ponto Final
		 * Linha 4 em diante - Coordenada das Paredes
		 * Separa��o das coordenadas por ','
		 * Exemplo:
		 * 3,4
		 * 0,1
		 * 3,3
		 * 0,2
		 * 1,2
		 * 1,3
		 * 3,2
		 * Dimens�o Labirinto = 3 x 4
		 * Ponto Inicial = i=0,j=1
		 * Ponto Final = i=3,j=3
		 * Paredes = {{0,2},{1,2},{1,3},{3,2}}
		 */
		String nomeArquivo = "C:\\Users\\23BI\\Documents\\labirinto.txt";
				
		AEstrela aEstrela = new AEstrela(nomeArquivo);
		
		aEstrela.exibirLabirinto();
		aEstrela.processo();
		aEstrela.exibirCustos();
		aEstrela.exibirCaminho();
	}

}