package AEstrelaLabirinto;

// Classe para definir os campos do labirinto
public class Campo {
	
	public int i,j; //Coordenadas
	public Campo parent; //Campo parent do caminho
	public int custoH; //Custo Heuristico do campo atual
	public int custoF; //G(n) + H(n)
	//G(n) custo do in�cio at� n
	//H(n) custo Heuristico mais econ�mico at� a sa�da
	public boolean caminho; //se o campo faz parte do caminho
	
	public Campo(int i, int j) {
		this.i = i;
		this.j = j;
	}
	
	@Override
	public String toString() {
		return "[" + i + "," + j + "]";
	}
}
